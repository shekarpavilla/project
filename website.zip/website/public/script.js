document.getElementById('searchForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;
    const date = document.getElementById('date').value;
  
    const results = document.getElementById('results');
    results.innerHTML = `
      <h3>Available Buses:</h3>
      <ul>
        <li>Bus 101 - 9:00 AM</li>
        <li>Bus 202 - 12:00 PM</li>
        <li>Bus 303 - 5:00 PM</li>
      </ul>
    `;
  });
  