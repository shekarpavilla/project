const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const USERS_FILE = './users.json';

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  const users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8') || '[]');

  if (users.find(u => u.email === email)) {
    return res.send('User already exists. <a href="/register.html">Go back</a>');
  }

  users.push({ name, email, password });
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  res.redirect('/login.html');
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8') || '[]');
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    res.send(`Welcome, ${user.name}! <a href="/index.html">Go to Home</a>`);
  } else {
    res.send('Invalid login. <a href="/login.html">Try again</a>');
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
